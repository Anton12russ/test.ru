window.externalScriptLoaded()

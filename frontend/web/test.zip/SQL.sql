-- MySQL dump 10.13  Distrib 5.5.62, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: test1
-- ------------------------------------------------------
-- Server version	5.5.62-0+deb8u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL,
  `verification_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `password_reset_token` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=216 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','-FwRj-tHEcgupHj5hxhYsLJ99vlvdByw','$2y$13$on295cEie6YPUtTmrG6t7eNPPOMHptTWIeLE21R/zY5EsnMcoiLlO','-9aC2cs5p4GXZCkfLLALOSLhvQOIrHFz_1577437255','admin@mari-turek.ru',10,1557856745,1605204746,'Ao-Ty9DzYp-DwbU3s7vPLtZBkeWL2W2V_1604341169'),(210,'Регистрация','tflp6x9-5EbX1w-IR485QOACUMGMPDu_','$2y$13$W4hjmth1kjSSftdEpmgWy.9pxKgpccfLBmoISrouUvz9GghGDjM5a',NULL,'sa@mail.ru',9,1651818803,1651818803,'DmtDJYDXzQDXd1LUC-O_BS6oWGye2sTF_1651818803'),(211,'test','y-oeQfgXVObLKJ_IbpbUe7nDrt2juTQG','$2y$13$3bUukDkhEc1clT1IoxXAiOaUHUnlEbiDWm7QL4SdWMqyz2YIMrJoS',NULL,'test@mail.ru',9,1651818830,1651818830,'yA-Qw14cIvvJC8zz8Pu4kNmGTm0UfEM6_1651818830'),(212,'test2','ECGdclR8_HcMSuRHZn2VfTgbRIJTtNWk','$2y$13$zJsCq8qvQbmV/7rE/osuhOy2//BQgxi8hK9WogbmqRnW2PYunGuhG',NULL,'test2@mail.ru',10,1651818878,1651818878,'o2vW4mTDjUsJAfEKmgw6LZXPhP4abfo8_1651818878'),(213,'Тест3','Li9snfP8_1Sa4dH3mXSuiJPKuBF2sctF','$2y$13$451swPLdDrnUGa/Ajtm.Zum3CocYZaxchHFNP.wpBlEzBpe3lNNb6',NULL,'a@maiil.ru',10,1651825513,1651825513,'RfRzq9enVXgiN_Jed52YYQunUJs_RhPA_1651825513'),(214,'Анна','s8RA9dEMD2YUB3S9hQ6uczec9TlsKa0A','$2y$13$N2VfveqmHbv1aNWyfxaA3O8R62cM3cfaNc7DmmY9CtcSrQuAuMS7i',NULL,'annaisa2008@yandex.ru',10,1651826464,1651826464,'_7Aix1iSdyH4KuPsJ12xPViREhoVoEQE_1651826464'),(215,'tttt@mail.ru','RHAMum6l32t3ZF7x6TL80ut3HfMn0jDN','$2y$13$7FeiweCMUC4HNUkDt8Iy7OZ0LMkXVyu3zYf7a9J4w/DEbhu5ORWiK',NULL,'tttt@mail.ru',10,1651826889,1651826889,'7z7i3TBE-hFG_Vfgmv8mYbn6Q_0s7GwZ_1651826889');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vopros`
--

DROP TABLE IF EXISTS `vopros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vopros` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `text` text NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vopros`
--

LOCK TABLES `vopros` WRITE;
/*!40000 ALTER TABLE `vopros` DISABLE KEYS */;
INSERT INTO `vopros` VALUES (50,'0',1),(51,'0',1),(52,'0',1),(53,'2',1),(54,'1',1),(55,'1',1),(56,'0',1),(57,'0',1),(58,'111',12),(59,'111',1),(60,'222',1),(61,'0',1),(62,'0',1),(63,'2',1),(64,'111',1),(65,'111',1),(66,'111',1),(67,'111',1),(68,'0',1),(69,'0',213),(70,'0',213),(71,'0',213),(72,'189',213),(73,'0',213),(74,'0',213),(75,'111',213),(76,'111',213),(77,'0',1),(78,'7890',1),(79,'7890',1),(80,'777',1),(81,'777',1),(82,'111',1),(83,'0',214),(84,'0',214),(85,'0',214),(86,'0',214),(87,'0',215),(88,'0',215),(89,'0',215),(90,'567',215),(91,'ert',215),(92,'ert',215),(93,'tryrtu',215);
/*!40000 ALTER TABLE `vopros` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-06 11:54:58
